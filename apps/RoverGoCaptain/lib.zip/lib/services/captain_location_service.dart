// lib/services/captain_location_service.dart
import 'dart:async';
import 'package:flutter/foundation.dart';   // <-- ADD THIS
import 'package:geolocator/geolocator.dart';
import '../socket/captain_socket.dart';

class CaptainLocationService {
  static StreamSubscription<Position>? _sub;
  static bool _running = false;

  static Future<bool> _ensurePermissions() async {
    bool enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) return false;

    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
    if (perm == LocationPermission.deniedForever || perm == LocationPermission.denied) {
      return false;
    }
    return true;
  }

  /// Start streaming location in background and emit to server via socket.
  /// `metadata` can include additional fields (e.g., captainId, rideId).
  static Future<void> startBackground({Map<String, dynamic>? metadata}) async {
    if (_running) return;
    final ok = await _ensurePermissions();
    if (!ok) {
      throw Exception('Location permissions not granted or service disabled');
    }

    final stream = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 5, // meters
      ),
    );

    _sub = stream.listen(
      (Position pos) {
        final payload = {
          'lat': pos.latitude,
          'lng': pos.longitude,
          'timestamp': DateTime.now().toIso8601String(),
          if (metadata != null) ...metadata,
        };
        CaptainSocket.emit('captain_location', payload);
      },
      onError: (e) {
        debugPrint('[loc] stream error: $e'); // Works now
      },
    );

    _running = true;
  }

  /// Stop streaming
  static Future<void> stopBackground() async {
    await _sub?.cancel();
    _sub = null;
    _running = false;
  }

  static bool isRunning() => _running;
}
