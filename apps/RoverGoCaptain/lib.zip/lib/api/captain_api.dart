// lib/api/captain_api.dart
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class CaptainApi {
  static const String baseUrl = "http://192.168.29.32:4000/api/captains";
  static String? token;
  static String? captainId;

  // ----------------------------------------------------------
  // SAVE TOKEN & CAPTAIN ID
  // ----------------------------------------------------------
  static Future<void> _saveSession(String t, String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString("captain_token", t);
    await prefs.setString("captain_id", id);

    token = t;
    captainId = id;
  }

  static Future<void> loadSession() async {
    final prefs = await SharedPreferences.getInstance();
    token = prefs.getString("captain_token");
    captainId = prefs.getString("captain_id");
  }

  // ----------------------------------------------------------
  // LOGIN  -> POST /api/captains/login
  // ----------------------------------------------------------
  static Future<Map<String, dynamic>> login(String phone, String password) async {
    final res = await http.post(
      Uri.parse("$baseUrl/login"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"phone": phone, "password": password}),
    );

    final data = jsonDecode(res.body);

    if (res.statusCode == 200 && data["token"] != null) {
      await _saveSession(data["token"], data["captain"]["id"]);
    }

    return data;
  }

  // ----------------------------------------------------------
  // REGISTER -> POST /api/captains/signup
  // ----------------------------------------------------------
  static Future<Map<String, dynamic>> register(
      String name, String phone, String password, String vehicleNo) async {
    final res = await http.post(
      Uri.parse("$baseUrl/signup"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "name": name,
        "phone": phone,
        "password": password,
        "vehicleNumber": vehicleNo,
      }),
    );

    return jsonDecode(res.body);
  }

  // ----------------------------------------------------------
  // GO ONLINE -> POST /api/captains/online
  // ----------------------------------------------------------
  static Future<bool> goOnline() async {
    if (captainId == null) return false;

    final res = await http.post(
      Uri.parse("$baseUrl/online"),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token"
      },
      body: jsonEncode({"captainId": captainId}),
    );

    return res.statusCode == 200;
  }

  // ----------------------------------------------------------
  // ACCEPT RIDE -> POST /api/captains/accept
  // ----------------------------------------------------------
  static Future<bool> acceptRide(String rideId) async {
    final res = await http.post(
      Uri.parse("$baseUrl/accept"),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token"
      },
      body: jsonEncode({
        "rideId": rideId,
        "captainId": captainId,
      }),
    );

    return res.statusCode == 200;
  }

  // ----------------------------------------------------------
  // REJECT RIDE -> POST /api/captains/reject
  // ----------------------------------------------------------
  static Future<bool> rejectRide(String rideId) async {
    final res = await http.post(
      Uri.parse("$baseUrl/reject"),
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token"
      },
      body: jsonEncode({
        "rideId": rideId,
        "captainId": captainId,
      }),
    );

    return res.statusCode == 200;
  }

  // ----------------------------------------------------------
  // GET EARNINGS -> GET /api/captains/:id/earnings?period=weekly
  // ----------------------------------------------------------
  static Future<Map<String, dynamic>?> getEarnings({String period = 'weekly'}) async {
    if (captainId == null || token == null) return null;

    final uri = Uri.parse("$baseUrl/$captainId/earnings?period=$period");

    try {
      final res = await http.get(
        uri,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $token",
        },
      );

      if (res.statusCode == 200) {
        return jsonDecode(res.body);
      } else {
        debugPrint("[CaptainApi] getEarnings failed: ${res.statusCode}");
        debugPrint(res.body);
        return null;
      }
    } catch (e) {
      debugPrint("[CaptainApi] getEarnings error: $e");
      return null;
    }
  }
}
