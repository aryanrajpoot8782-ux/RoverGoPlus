import 'package:flutter/material.dart';
import '../api/captain_api.dart';

class EarningsDashboard extends StatefulWidget {
  const EarningsDashboard({super.key});

  @override
  State<EarningsDashboard> createState() => _EarningsDashboardState();
}

class _EarningsDashboardState extends State<EarningsDashboard> {
  bool _loading = true;
  Map<String, dynamic>? data;
  final String _currency = "₹";

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final res = await CaptainApi.getEarnings(period: "weekly");
    setState(() {
      data = res;
      _loading = false;
    });
  }

  // simple formatter: 2000 → "2k"
  String fmt(num n) {
    if (n >= 1000) return "${(n / 1000).toStringAsFixed(1)}k";
    return n.toString();
  }

  @override
  Widget build(BuildContext context) {
    final today = data?["today"] ?? {};
    final summary = data?["summary"] ?? {};
    final weekly = List<Map<String, dynamic>>.from(data?["weekly"] ?? []);

    // find max bar height
    num maxEarn = 1;
    if (weekly.isNotEmpty) {
      maxEarn = weekly.map((e) => (e["earnings"] ?? 0) as num).reduce((a, b) => a > b ? a : b);
      if (maxEarn <= 0) maxEarn = 1;
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text("Earnings"),
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        _card("Today", "$_currency${today["earnings"] ?? 0}", subtitle: "${today["rides"] ?? 0} rides"),
                        const SizedBox(width: 10),
                        _card("Total", "$_currency${summary["total_earnings"] ?? 0}",
                            subtitle: "${summary["total_rides"] ?? 0} rides"),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _card("Distance", "${today["distance_km"] ?? 0} km"),
                        const SizedBox(width: 10),
                        _card("Online", "${today["online_minutes"] ?? 0} mins"),
                      ],
                    ),
                    const SizedBox(height: 20),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text("This Week", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      height: 180,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Theme.of(context).cardColor,
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: weekly.map((day) {
                          final n = day["earnings"] ?? 0;
                          final pct = (n / maxEarn);
                          final height = pct * 140;

                          return Expanded(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(fmt(n)),
                                const SizedBox(height: 4),
                                Container(
                                  width: 20,
                                  height: height.toDouble(),
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).primaryColor,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(day["day"] ?? "", style: const TextStyle(fontSize: 12)),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Column(
                          children: [
                            _row("Total earnings", "$_currency${summary["total_earnings"] ?? 0}"),
                            const SizedBox(height: 6),
                            _row("Total rides", "${summary["total_rides"] ?? 0}"),
                            const SizedBox(height: 6),
                            _row("Total distance", "${summary["total_distance_km"] ?? 0} km"),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
      ),
    );
  }

  Widget _row(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label),
        Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _card(String label, String value, {String? subtitle}) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(color: Colors.grey)),
              const SizedBox(height: 6),
              Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              if (subtitle != null) ...[
                const SizedBox(height: 4),
                Text(subtitle, style: const TextStyle(color: Colors.grey)),
              ]
            ],
          ),
        ),
      ),
    );
  }
}
