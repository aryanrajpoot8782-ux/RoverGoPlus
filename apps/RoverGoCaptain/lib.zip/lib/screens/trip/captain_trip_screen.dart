// lib/screens/trip/captain_trip_screen.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

import '../../socket/captain_socket.dart';
import '../../api/captain_api.dart';
import '../../services/captain_location_service.dart';

import '../../api/directions_api.dart';
import '../../utils/polyline_decoder.dart';
import '../ride_summary_screen.dart';

class CaptainTripScreen extends StatefulWidget {
  final Map<String, dynamic> ride;

  const CaptainTripScreen({super.key, required this.ride});

  @override
  State<CaptainTripScreen> createState() => _CaptainTripScreenState();
}

class _CaptainTripScreenState extends State<CaptainTripScreen> {
  final Completer<GoogleMapController> _mapController = Completer();
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};
  StreamSubscription<Position>? _posSub;

  LatLng? _captainPosition;
  int tripState = 0; // 0=picking,1=arrived,2=ontrip,3=completed
  int _polylineId = 1;

  @override
  void initState() {
    super.initState();
    CaptainSocket.connect();
    _addRideMarkers();
    _startLocalLocationListener();

    // Trip-specific socket listeners
    CaptainSocket.on('ride_cancelled', _onRemoteCancelled);
    CaptainSocket.on('arrived_at_pickup', _onRemoteArrived);
    CaptainSocket.on('start_ride', _onRemoteStart);
    CaptainSocket.on('complete_ride', _onRemoteComplete);
  }

  @override
  void dispose() {
    _posSub?.cancel();
    CaptainSocket.off('ride_cancelled');
    CaptainSocket.off('arrived_at_pickup');
    CaptainSocket.off('start_ride');
    CaptainSocket.off('complete_ride');
    super.dispose();
  }

  // -------------------------
  // markers
  // -------------------------
  void _addRideMarkers() {
    try {
      final pickupLat = widget.ride['pickup_lat'];
      final pickupLng = widget.ride['pickup_lng'];
      final dropLat = widget.ride['drop_lat'];
      final dropLng = widget.ride['drop_lng'];

      if (pickupLat != null && pickupLng != null) {
        final pick = LatLng(pickupLat.toDouble(), pickupLng.toDouble());
        _markers.add(Marker(markerId: const MarkerId('pickup'), position: pick, infoWindow: const InfoWindow(title: 'Pickup')));
      }
      if (dropLat != null && dropLng != null) {
        final drop = LatLng(dropLat.toDouble(), dropLng.toDouble());
        _markers.add(Marker(markerId: const MarkerId('drop'), position: drop, infoWindow: const InfoWindow(title: 'Drop')));
      }
    } catch (e) {
      debugPrint('[trip] addRideMarkers error: $e');
    }
  }

  // -------------------------
  // Location streaming & map updates
  // -------------------------
  Future<void> _startLocalLocationListener() async {
    final ok = await _ensureLocationPermission();
    if (!ok) {
      debugPrint('[trip] location permission not granted');
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enable location services'), backgroundColor: Colors.red));
      return;
    }

    try {
      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
      final latlng = LatLng(pos.latitude, pos.longitude);
      _updateCaptainMarker(latlng, moveCamera: true);

      // Draw initial route captain -> pickup (if available)
      final pickupLat = widget.ride['pickup_lat'];
      final pickupLng = widget.ride['pickup_lng'];
      if (pickupLat != null && pickupLng != null) {
        final pickup = LatLng(pickupLat.toDouble(), pickupLng.toDouble());
        _drawRoute(latlng, pickup);
      }
    } catch (e) {
      debugPrint('[trip] initial pos error: $e');
    }

    _posSub = Geolocator.getPositionStream(locationSettings: const LocationSettings(accuracy: LocationAccuracy.bestForNavigation, distanceFilter: 5)).listen((Position pos) {
      final latlng = LatLng(pos.latitude, pos.longitude);
      _updateCaptainMarker(latlng);

      CaptainSocket.emit('captain_location', {
        'lat': pos.latitude,
        'lng': pos.longitude,
        'rideId': widget.ride['id'] ?? widget.ride['_id'] ?? widget.ride['rideId'],
        'captainId': CaptainApi.captainId,
        'timestamp': DateTime.now().toIso8601String(),
      });
    }, onError: (e) => debugPrint('[trip] pos stream error: $e'));
  }

  Future<bool> _ensureLocationPermission() async {
    bool enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) return false;
    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) perm = await Geolocator.requestPermission();
    if (perm == LocationPermission.denied || perm == LocationPermission.deniedForever) return false;
    return true;
  }

  void _updateCaptainMarker(LatLng pos, {bool moveCamera = false}) async {
    setState(() {
      _captainPosition = pos;
      _markers.removeWhere((m) => m.markerId.value == 'captain');
      _markers.add(Marker(markerId: const MarkerId('captain'), position: pos, infoWindow: const InfoWindow(title: 'You')));
    });
    if (moveCamera) {
      final controller = await _mapController.future;
      controller.animateCamera(CameraUpdate.newLatLngZoom(pos, 15));
    }
  }

  // -------------------------
  // routing helpers
  // -------------------------
  Future<void> _drawRoute(LatLng origin, LatLng destination) async {
    try {
      final encoded = await DirectionsApi.getRoutePolyline(origin, destination);
      if (encoded == null || encoded.isEmpty) return;
      final points = PolylineDecoder.decodePolyline(encoded);

      final polyId = PolylineId("route_${_polylineId++}");
      setState(() {
        _polylines.add(Polyline(polylineId: polyId, width: 5, points: points));
      });

      _fitCameraToPolyline(points);
    } catch (e) {
      debugPrint('[route] draw error: $e');
    }
  }

  Future<void> _fitCameraToPolyline(List<LatLng> points) async {
    if (points.isEmpty) return;

    double minLat = points.first.latitude, maxLat = points.first.latitude;
    double minLng = points.first.longitude, maxLng = points.first.longitude;

    for (final p in points) {
      if (p.latitude < minLat) minLat = p.latitude;
      if (p.latitude > maxLat) maxLat = p.latitude;
      if (p.longitude < minLng) minLng = p.longitude;
      if (p.longitude > maxLng) maxLng = p.longitude;
    }

    final controller = await _mapController.future;
    controller.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds(northeast: LatLng(maxLat, maxLng), southwest: LatLng(minLat, minLng)), 50));
  }

  // -------------------------
  // socket-driven handlers for trip
  // -------------------------
  void _onRemoteCancelled(dynamic data) {
    final cancelledId = data?['rideId'] ?? data?['_id'] ?? data;
    final myId = widget.ride['id'] ?? widget.ride['_id'] ?? widget.ride['rideId'];
    if (myId != null && cancelledId != null && cancelledId.toString() == myId.toString()) {
      _handleRemoteCancellation();
    }
  }

  void _onRemoteArrived(dynamic data) {
    final rideId = data?['rideId'] ?? data?['_id'] ?? data;
    final myId = widget.ride['id'] ?? widget.ride['_id'] ?? widget.ride['rideId'];
    if (myId != null && rideId != null && rideId.toString() == myId.toString()) {
      setState(() => tripState = 1);
    }
  }

  void _onRemoteStart(dynamic data) {
    final rideId = data?['rideId'] ?? data?['_id'] ?? data;
    final myId = widget.ride['id'] ?? widget.ride['_id'] ?? widget.ride['rideId'];
    if (myId != null && rideId != null && rideId.toString() == myId.toString()) {
      setState(() => tripState = 2);
    }
  }

  void _onRemoteComplete(dynamic data) {
    final rideId = data?['rideId'] ?? data?['_id'] ?? data;
    final myId = widget.ride['id'] ?? widget.ride['_id'] ?? widget.ride['rideId'];
    if (myId != null && rideId != null && rideId.toString() == myId.toString()) {
      _navigateToSummary();
    }
  }

  void _handleRemoteCancellation() {
    if (Navigator.canPop(context)) Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ride cancelled by user'), backgroundColor: Colors.red));
  }

  void _navigateToSummary() async {
    // Ideally use server-provided summary; for now fallback to ride object
    final distanceKm = (widget.ride['distance_km'] ?? 0).toDouble();
    final durationSeconds = (widget.ride['duration_seconds'] ?? 0) as int;
    final fare = (widget.ride['fare'] ?? 0).toDouble();
    final paymentMode = (widget.ride['payment_mode'] ?? 'Cash').toString();

    // stop background location stream
    await CaptainLocationService.stopBackground();

    if (mounted) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => RideSummaryScreen(
            ride: widget.ride,
            distanceKm: distanceKm,
            durationSeconds: durationSeconds,
            fare: fare,
            paymentMode: paymentMode,
          ),
        ),
      );
    }
  }

  // -------------------------
  // local button handlers
  // -------------------------
  Future<void> _onArrivedAtPickup() async {
    setState(() => tripState = 1);
    final rideId = widget.ride['id'] ?? widget.ride['_id'] ?? widget.ride['rideId'];
    CaptainSocket.emit('arrived_at_pickup', {'rideId': rideId, 'captainId': CaptainApi.captainId});
  }

  Future<void> _onStartRide() async {
    setState(() => tripState = 2);
    final rideId = widget.ride['id'] ?? widget.ride['_id'] ?? widget.ride['rideId'];
    CaptainSocket.emit('start_ride', {'rideId': rideId, 'captainId': CaptainApi.captainId});

    // Ensure background streaming for this ride
    try {
      await CaptainLocationService.startBackground(metadata: {'captainId': CaptainApi.captainId, 'rideId': rideId.toString()});
    } catch (e) {
      debugPrint('[trip] location start error: $e');
    }

    // Draw pickup->drop route if coordinates exist
    final pLat = widget.ride['pickup_lat'];
    final pLng = widget.ride['pickup_lng'];
    final dLat = widget.ride['drop_lat'];
    final dLng = widget.ride['drop_lng'];
    if (pLat != null && pLng != null && dLat != null && dLng != null) {
      _drawRoute(LatLng(pLat.toDouble(), pLng.toDouble()), LatLng(dLat.toDouble(), dLng.toDouble()));
    }
  }

  Future<void> _onCompleteRide() async {
    setState(() => tripState = 3);
    final rideId = widget.ride['id'] ?? widget.ride['_id'] ?? widget.ride['rideId'];
    CaptainSocket.emit('complete_ride', {'rideId': rideId, 'captainId': CaptainApi.captainId});

    // optionally call CaptainApi.completeRide and get server summary
    await CaptainLocationService.stopBackground();
    _navigateToSummary();
  }

  Widget _actionButton() {
    switch (tripState) {
      case 0:
        return ElevatedButton.icon(onPressed: _onArrivedAtPickup, icon: const Icon(Icons.my_location), label: const Text('Arrived at Pickup'));
      case 1:
        return ElevatedButton.icon(onPressed: _onStartRide, icon: const Icon(Icons.play_arrow), label: const Text('Start Ride'));
      case 2:
        return ElevatedButton.icon(onPressed: _onCompleteRide, icon: const Icon(Icons.check), label: const Text('Complete Ride'));
      default:
        return const SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    final initialCam = CameraPosition(target: _captainPosition ?? const LatLng(21.0, 78.0), zoom: 15);

    return Scaffold(
      appBar: AppBar(title: const Text('Trip')),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: initialCam,
            onMapCreated: (controller) => _mapController.complete(controller),
            markers: _markers,
            polylines: _polylines,
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
            zoomControlsEnabled: false,
          ),
          Positioned(left: 12, right: 12, bottom: 36, child: SafeArea(child: Row(children: [Expanded(child: _actionButton())]))),
        ],
      ),
    );
  }
}
