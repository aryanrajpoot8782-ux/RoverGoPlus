// lib/socket/captain_socket.dart
import 'package:flutter/foundation.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;

/// CaptainSocket
///
/// Responsibilities:
///  - connect/disconnect idempotently
///  - auto-reconnect with retries
///  - emit events (queues while disconnected)
///  - register/unregister listeners
///  - automatically re-assert "online" status on reconnect
class CaptainSocket {
  static io.Socket? _socket;

  /// Your backend socket URL. Change to your deployed backend when ready.
  static const String _url = "http://192.168.29.32:4000";

  /// Queue events to send when socket reconnects.
  /// Each queued item is { event: String, data: dynamic }.
  static final List<Map<String, dynamic>> _eventQueue = [];

  /// Application-level flags (e.g., "isOnline" set by the UI).
  /// Used to re-assert state after reconnect.
  static bool _isOnline = false;
  static String? _captainIdWhenOnline;

  /// Connect to socket idempotently.
  static void connect() {
    try {
      if (_socket != null && _socket!.connected) {
        debugPrint('[socket] already connected (${_socket!.id})');
        return;
      }

      debugPrint('[socket] connecting to $_url ...');

      _socket = io.io(
        _url,
        io.OptionBuilder()
            .setTransports(['websocket'])
            .enableAutoConnect()
            .enableReconnection()
            .setReconnectionAttempts(9999) // effectively infinite retries
            .setReconnectionDelay(2000) // ms
            .setExtraHeaders({'accept': 'application/json'})
            .build(),
      );

      // Core lifecycle listeners
      _socket?.on('connect', (_) {
        debugPrint('[socket] connected id=${_socket?.id}');
        _flushQueue();
        _reassertStateAfterReconnect();
      });

      _socket?.on('connect_error', (err) {
        debugPrint('[socket] connect_error: $err');
      });

      _socket?.on('reconnect_attempt', (attempt) {
        debugPrint('[socket] reconnect attempt: $attempt');
      });

      _socket?.on('reconnect_failed', (_) {
        debugPrint('[socket] reconnect_failed');
      });

      _socket?.on('disconnect', (reason) {
        debugPrint('[socket] disconnected: $reason');
      });

      // Generic error handling
      _socket?.on('error', (err) {
        debugPrint('[socket] error: $err');
      });
    } catch (e) {
      debugPrint('[socket] connect exception: $e');
    }
  }

  /// Disconnect and cleanup socket instance.
  static void disconnect() {
    try {
      if (_socket != null) {
        debugPrint('[socket] disconnecting');
        _socket?.disconnect();
        _socket?.destroy();
      }
    } catch (e) {
      debugPrint('[socket] disconnect error: $e');
    } finally {
      _socket = null;
    }
  }

  /// Emit an event. If socket is not connected, push to queue.
  ///
  /// Example:
  ///   CaptainSocket.emit('captain_location', { 'lat': ..., 'lng': ... });
  static void emit(String event, dynamic data, {bool queueIfDisconnected = true}) {
    try {
      if (_socket == null || !_socket!.connected) {
        debugPrint('[socket] not connected, emit queued: $event -> $data');
        if (queueIfDisconnected) {
          _eventQueue.add({'event': event, 'data': data});
        }
        return;
      }
      _socket?.emit(event, data);
      debugPrint('[socket] emit: $event -> $data');
    } catch (e) {
      debugPrint('[socket] emit error: $e');
      if (queueIfDisconnected) {
        _eventQueue.add({'event': event, 'data': data});
      }
    }
  }

  /// Register listener for server events.
  /// cb receives dynamic payload (Map or primitive depending on backend).
  static void on(String event, void Function(dynamic)? cb) {
    if (cb == null) return;
    try {
      if (_socket == null) connect();
      _socket?.on(event, cb);
      debugPrint('[socket] listening on: $event');
    } catch (e) {
      debugPrint('[socket] on error: $e');
    }
  }

  /// Register a one-time listener.
  static void once(String event, void Function(dynamic)? cb) {
    if (cb == null) return;
    try {
      if (_socket == null) connect();
      _socket?.once(event, cb);
      debugPrint('[socket] once: $event');
    } catch (e) {
      debugPrint('[socket] once error: $e');
    }
  }

  /// Remove listener for event.
  static void off(String event) {
    try {
      _socket?.off(event);
      debugPrint('[socket] off: $event');
    } catch (e) {
      debugPrint('[socket] off error: $e');
    }
  }

  /// Flush queued events when socket reconnects.
  static void _flushQueue() {
    if (_eventQueue.isEmpty) return;
    debugPrint('[socket] flushing ${_eventQueue.length} queued events');
    try {
      for (final item in List<Map<String, dynamic>>.from(_eventQueue)) {
        final event = item['event'] as String?;
        final data = item['data'];
        if (event != null) {
          _socket?.emit(event, data);
        }
      }
      _eventQueue.clear();
    } catch (e) {
      debugPrint('[socket] flushQueue error: $e');
    }
  }

  /// Application-level helper: set the captain online flag (used by Home UI)
  /// When set to true, this value will be re-emitted after reconnect.
  static void setOnline({required bool online, String? captainId}) {
    _isOnline = online;
    _captainIdWhenOnline = captainId;
    if (online) {
      emit('captain_online', {'status': 'online', 'captainId': captainId}, queueIfDisconnected: true);
    } else {
      emit('captain_offline', {'status': 'offline', 'captainId': captainId}, queueIfDisconnected: true);
    }
  }

  /// When socket reconnects, re-assert any important application state
  /// (for now, re-send captain_online if the user was online).
  static void _reassertStateAfterReconnect() {
    try {
      if (_isOnline && _captainIdWhenOnline != null) {
        debugPrint('[socket] reassert online state for captainId=$_captainIdWhenOnline');
        emit('captain_online', {'status': 'online', 'captainId': _captainIdWhenOnline}, queueIfDisconnected: false);
      }
    } catch (e) {
      debugPrint('[socket] reassert error: $e');
    }
  }

  /// Utility: returns true if connected now.
  static bool get isConnected => _socket?.connected ?? false;

  /// Utility: get socket id (if connected)
  static String? get socketId => _socket?.id;
}
