import 'package:flutter/material.dart';
import 'api/captain_api.dart';
import 'screens/auth/login_screen.dart';
import 'screens/home/captain_home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await CaptainApi.loadSession(); // load saved login

  runApp(const RoverGoCaptainApp());
}

class RoverGoCaptainApp extends StatelessWidget {
  const RoverGoCaptainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      // If captainId exists → go to Home
      // else → show Login
      home: CaptainApi.captainId == null
          ? const CaptainLoginScreen()
          : const CaptainHomeScreen(),
    );
  }
}
